import 'package:flutter/material.dart';

class ChatBotScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chat Bot'),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: Center(
        child: Text(
          'Chat with our bot',
          style: TextStyle(fontSize: 24.0),
        ),
      ),
    );
  }
}
