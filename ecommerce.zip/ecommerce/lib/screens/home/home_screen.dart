import 'package:flutter/material.dart';

// Model class for Cart Item
class CartItem {
  final String productName;
  final String address;
  final String phoneNumber;
  final String email;

  CartItem({
    required this.productName,
    required this.address,
    required this.phoneNumber,
    required this.email,
  });
}

// Model class for Toy Item
class Toy {
  final String name;
  final String imagePath;

  Toy({required this.name, required this.imagePath});
}

void main() {
  runApp(MaterialApp(
    home: HomeScreen(),
  ));
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _isHoveredFeature1 = false;
  bool _isHoveredFeature2 = false;
  List<CartItem> cartItems = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
        centerTitle: true,
        backgroundColor: Colors.yellowAccent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.popUntil(context, ModalRoute.withName('/'));
          },
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              // Implement search functionality
            },
          ),
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: () {
              _navigateToCartScreen();
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: EdgeInsets.all(20.0),
              color: Colors.blueAccent,
              child: Text(
                'Discover Latest Trends!',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 28.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            SizedBox(height: 20.0),
            _buildCategoryList(),
            SizedBox(height: 20.0),
            _buildFeaturedProducts(),
            SizedBox(height: 20.0),
            _buildPopularProducts(),
            SizedBox(height: 20.0),
            _buildToysScreen(), // Added Toys screen widget
            SizedBox(height: 20.0),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => ChatBotScreen()),
          );
        },
        child: Icon(Icons.chat),
        backgroundColor: Colors.teal,
      ),
    );
  }

  Widget _buildCategoryList() {
    return Container(
      height: 100.0,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          _buildCategoryItem('Home', Icons.home),
          _buildCategoryItem('Toys', Icons.toys),
          _buildCategoryItem('Mobile Accessories', Icons.headset),
        ],
      ),
    );
  }

  Widget _buildCategoryItem(String name, IconData icon) {
    return GestureDetector(
      onTap: () {
        if (name == 'Mobile Accessories') {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => MobileAccessoriesScreen(
                onAddToCart: _addToCart,
              ),
            ),
          );
        } else if (name == 'Toys') {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ToysScreen(
                onAddToCart: _addToCart,
              ),
            ),
          );
        }
      },
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 10.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40.0, color: Colors.blue),
            SizedBox(height: 5.0),
            Text(name, style: TextStyle(fontSize: 16.0)),
          ],
        ),
      ),
    );
  }

  Widget _buildFeaturedProducts() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'Featured Products',
            style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 10.0),
          GestureDetector(
            onTap: () {
              _navigateToAddToCartScreen('Phone', '123 Street, City',
                  '+1234567890', 'email@example.com');
              setState(() {
                _isHoveredFeature1 = !_isHoveredFeature1;
              });
            },
            child: AnimatedContainer(
              duration: Duration(seconds: 1),
              height: _isHoveredFeature1 ? 220.0 : 200.0,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Center(
                child: Image.asset(
                  'assets/images/phone.png',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPopularProducts() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'Popular Products',
            style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 10.0),
          GestureDetector(
            onTap: () {
              _navigateToAddToCartScreen('Laptop', '456 Avenue, Town',
                  '+9876543210', 'email@example.com');
              setState(() {
                _isHoveredFeature2 = !_isHoveredFeature2;
              });
            },
            child: AnimatedContainer(
              duration: Duration(seconds: 1),
              height: _isHoveredFeature2 ? 220.0 : 200.0,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Center(
                child: Image.asset(
                  'assets/images/laptop2.png',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildToysScreen() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'Toys',
            style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 10.0),
          GestureDetector(
            onTap: () {
              _navigateToAddToCartScreen('Teddy Bear', '789 Lane, Village',
                  '+2468135790', 'email@example.com');
            },
            child: AnimatedContainer(
              duration: Duration(seconds: 1),
              height: 200.0,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Center(
                child: Image.asset(
                  'assets/images/teddy_bear.png',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _navigateToAddToCartScreen(
      String productName, String address, String phoneNumber, String email) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddToCartScreen(
          productName: productName,
          address: address,
          phoneNumber: phoneNumber,
          email: email,
          onAddToCart: (productName, address, phoneNumber, email) {
            _addToCart(productName, address, phoneNumber, email);
          },
        ),
      ),
    );
  }

  void _addToCart(
      String productName, String address, String phoneNumber, String email) {
    CartItem item = CartItem(
      productName: productName,
      address: address,
      phoneNumber: phoneNumber,
      email: email,
    );
    setState(() {
      cartItems.add(item);
    });
  }

  void _navigateToCartScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CartScreen(cartItems: cartItems),
      ),
    );
  }
}

class AddToCartScreen extends StatefulWidget {
  final String productName;
  final String address;
  final String phoneNumber;
  final String email;
  final Function(String, String, String, String) onAddToCart;

  AddToCartScreen({
    required this.productName,
    required this.address,
    required this.phoneNumber,
    required this.email,
    required this.onAddToCart,
  });

  @override
  _AddToCartScreenState createState() => _AddToCartScreenState();
}

class _AddToCartScreenState extends State<AddToCartScreen> {
  TextEditingController addressController = TextEditingController();
  TextEditingController phoneNumberController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController cardNumberController = TextEditingController();
  TextEditingController expiryDateController = TextEditingController();
  TextEditingController cvvController = TextEditingController();

  @override
  void dispose() {
    addressController.dispose();
    phoneNumberController.dispose();
    emailController.dispose();
    cardNumberController.dispose();
    expiryDateController.dispose();
    cvvController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    addressController.text = widget.address;
    phoneNumberController.text = widget.phoneNumber;
    emailController.text = widget.email;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add to Cart'),
        centerTitle: true,
        backgroundColor: Colors.yellowAccent,
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          children: [
            Text(
              widget.productName,
              style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20.0),
            TextField(
              controller: addressController,
              decoration: InputDecoration(labelText: 'Address'),
            ),
            TextField(
              controller: phoneNumberController,
              decoration: InputDecoration(labelText: 'Phone Number'),
            ),
            TextField(
              controller: emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: cardNumberController,
              decoration: InputDecoration(labelText: 'Card Number'),
            ),
            TextField(
              controller: expiryDateController,
              decoration: InputDecoration(labelText: 'Expiry Date'),
            ),
            TextField(
              controller: cvvController,
              decoration: InputDecoration(labelText: 'CVV'),
            ),
            SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () {
                widget.onAddToCart(
                  widget.productName,
                  addressController.text,
                  phoneNumberController.text,
                  emailController.text,
                );
                Navigator.pop(context);
              },
              child: Text('Add to Cart'),
            ),
          ],
        ),
      ),
    );
  }
}

class CartScreen extends StatelessWidget {
  final List<CartItem> cartItems;

  CartScreen({required this.cartItems});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cart'),
        centerTitle: true,
        backgroundColor: Colors.yellowAccent,
      ),
      body: ListView.builder(
        itemCount: cartItems.length,
        itemBuilder: (context, index) {
          final item = cartItems[index];
          return ListTile(
            title: Text(item.productName),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Address: ${item.address}'),
                Text('Phone: ${item.phoneNumber}'),
                Text('Email: ${item.email}'),
              ],
            ),
          );
        },
      ),
    );
  }
}

class MobileAccessoriesScreen extends StatelessWidget {
  final Function(String, String, String, String) onAddToCart;

  // Example list of mobile accessories
  final List<Map<String, dynamic>> mobileAccessories = [
    {
      'name': 'Headphones',
      'price': '\$50',
      'imagePath': 'assets/images/headphones.png',
    },
    {
      'name': 'Phone Case',
      'price': '\$20',
      'imagePath': 'assets/images/case.png',
    },
    {
      'name': 'charger',
      'price': '\$20',
      'imagePath': 'assets/images/charger.png',
    },
    // Add more accessories as needed
  ];

  MobileAccessoriesScreen({required this.onAddToCart});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mobile Accessories'),
        centerTitle: true,
        backgroundColor: Colors.yellowAccent,
      ),
      body: ListView.builder(
        itemCount: mobileAccessories.length,
        itemBuilder: (context, index) {
          final accessory = mobileAccessories[index];
          return ListTile(
            title: Text(accessory['name']),
            subtitle: Text(accessory['price']),
            leading: CircleAvatar(
              backgroundImage: AssetImage(accessory['imagePath']),
            ),
            onTap: () {
              // Navigate to Add to Cart screen or perform action
              onAddToCart(
                accessory['name'],
                accessory['price'],
                accessory['imagePath'],
                accessory['address'],
                // Add any additional details needed
              );
            },
          );
        },
      ),
    );
  }
}

class ToysScreen extends StatelessWidget {
  final Function(String, String, String, String) onAddToCart;

  ToysScreen({required this.onAddToCart});

  final List<Toy> toys = [
    Toy(name: 'Teddy Bear', imagePath: 'assets/images/teddy_bear.png'),
    Toy(name: 'Toy Car', imagePath: 'assets/images/remote_car.png'),
    Toy(name: 'Doll', imagePath: 'assets/images/doll_house.png'),
    Toy(name: 'building blocks', imagePath: 'assets/images/building_blocks.png')
    // Add more toys here
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(66, 18, 192, 223),
      appBar: AppBar(
        title: Text('Toys'),
        centerTitle: true,
        backgroundColor: Colors.yellowAccent,
      ),
      body: ListView.builder(
        itemCount: toys.length,
        itemBuilder: (context, index) {
          final toy = toys[index];
          return ListTile(
            leading: Image.asset(toy.imagePath, width: 50, height: 50),
            title: Text(toy.name),
            onTap: () {
              // Navigate to AddToCartScreen when a toy is tapped
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => AddToCartScreen(
                    productName: toy.name,
                    address:
                        '', // You can set default address or leave it empty
                    phoneNumber: '', // Default phone number or leave it empty
                    email: '', // Default email or leave it empty
                    onAddToCart: onAddToCart,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class ChatBotScreen extends StatefulWidget {
  @override
  _ChatBotScreenState createState() => _ChatBotScreenState();
}

class _ChatBotScreenState extends State<ChatBotScreen> {
  TextEditingController messageController = TextEditingController();
  String botResponse = '';
  bool isLoading = false;

  void handleMessage(String message) async {
    setState(() {
      isLoading = true;
    });

    await Future.delayed(
        Duration(seconds: 1)); // Simulate a delay for processing

    if (message.toLowerCase() == 'hi' || message.toLowerCase() == 'hello') {
      setState(() {
        botResponse = 'Hi! How can I help you?';
        isLoading = false;
      });
    } else {
      setState(() {
        botResponse = 'I didn\'t understand that. Could you please rephrase?';
        isLoading = false;
      });
    }

    // Debug prints
    print('handleMessage: $message');
    print('botResponse: $botResponse');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chat Bot'),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.teal.shade300, Colors.teal.shade800],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  'Chat with our bot',
                  style: TextStyle(fontSize: 24.0, color: Colors.white),
                ),
                SizedBox(height: 20.0),
                TextField(
                  controller: messageController,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.white,
                    hintText: 'Type your message here...',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide.none,
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(Icons.send),
                      onPressed: () {
                        String message = messageController.text.trim();
                        if (message.isNotEmpty) {
                          handleMessage(message);
                          messageController.clear();
                        }
                      },
                    ),
                  ),
                  onSubmitted: (value) {
                    if (value.trim().isNotEmpty) {
                      handleMessage(value.trim());
                      messageController.clear();
                    }
                  },
                ),
                SizedBox(height: 20.0),
                if (isLoading) CircularProgressIndicator(),
                SizedBox(height: 20.0),
                if (botResponse.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 20.0),
                    child: Text(
                      botResponse,
                      style: TextStyle(fontSize: 18.0, color: Colors.white),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
