import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'signup_screen.dart';
import 'package:ecommerce/screens/home/home_screen.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final FacebookAuth _facebookAuth = FacebookAuth.instance;

  // Animation properties
  bool _isAnimated = false;
  final Duration _animationDuration = Duration(milliseconds: 500);

  void _login() {
    // Implement login functionality
    // For now, navigate to home screen after login
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => HomeScreen()),
    );
  }

  // Sign in with Google
  Future<void> _signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser != null) {
        // Navigate to home screen after successful login
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomeScreen()),
        );
      }
    } catch (e) {
      print('Error signing in with Google: $e');
    }
  }

  // Sign in with Facebook
  Future<void> _signInWithFacebook() async {
    try {
      final LoginResult result = await _facebookAuth.login();
      if (result.status == LoginStatus.success) {
        // Navigate to home screen after successful login
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomeScreen()),
        );
      } else {
        print('Facebook login failed. Status: ${result.status}');
      }
    } catch (e) {
      print('Error signing in with Facebook: $e');
    }
  }

  @override
  void initState() {
    super.initState();
    // Start the animation when the screen loads
    Future.delayed(Duration(milliseconds: 100), () {
      setState(() {
        _isAnimated = true;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blue, Colors.purple],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                      child: Column(
                        children: [
                          AnimatedContainer(
                            duration: _animationDuration,
                            curve: Curves.easeInOut,
                            transform: _isAnimated
                                ? Matrix4.translationValues(0, -10, 0)
                                : Matrix4.translationValues(0, 0, 0),
                            child: Image.asset(
                              'assets/images/logo2.png', // Replace with your logo asset path
                              height: 100.0, // Adjust the height as needed
                            ),
                          ),
                          SizedBox(height: 20.0),
                          Text(
                            'E-Commerce Store!',
                            style: TextStyle(
                              fontSize: 32.0,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(height: 20.0),
                          ElevatedButton.icon(
                            onPressed: _signInWithGoogle,
                            icon: Icon(Icons.g_translate),
                            label: Text('Sign in with Google'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red, // background color
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20.0),
                              ),
                            ),
                          ),
                          SizedBox(height: 20.0),
                          AnimatedContainer(
                            duration: _animationDuration,
                            curve: Curves.easeInOut,
                            transform: _isAnimated
                                ? Matrix4.translationValues(0, 10, 0)
                                : Matrix4.translationValues(0, 0, 0),
                            child: ElevatedButton.icon(
                              onPressed: _signInWithFacebook,
                              icon: Icon(Icons.facebook),
                              label: Text('Sign in with Facebook'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor:
                                    Colors.blue, // background color
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20.0),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 20.0),
                          TextButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => SignupScreen()),
                              );
                            },
                            child: Text(
                              'Don\'t have an account? Sign up',
                              style: TextStyle(
                                color: Colors.white,
                                decoration: TextDecoration.underline,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 20.0),
                    // Your white blank asset image here
                    Container(
                      width: 100.0, // Adjust width as needed
                      height: 100.0, // Adjust height as needed
                      color: Colors.white, // Placeholder color
                      // Replace with your white blank asset image
                      child: Image.asset('assets/images/commerce.png'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
